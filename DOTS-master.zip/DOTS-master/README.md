# DOTS
DOTS - Train your Brain. Android App
   
![aa](https://github.com/asirihewage/DOTS/blob/master/SCREENSHOTS/banner2.png)

This is a brain game where you can select DOTS as faster as possible to analyse the functionality of your brain. You can play Head-to-Head mode to compare with your friend.

Are you ready, adventurer? Let’s go!

##  WHY YOU’LL LOVE DOTS

-  FREE to play!
- CHALLENGE yourself and give your friend a challenge.
- Show your DOTS rank to the world.
- ENJOY simple, thoughtful game-play.
- ANALYSE how powerful your brain is.

###  WHAT IS "DOTS RANK" ?

DOTS RANK is the measurement of brain power. Using this application you can see your position among millions of DOTS users.

If you loved DOTS, please make a review with your latest score!

![aa](https://github.com/asirihewage/DOTS/blob/master/SCREENSHOTS/2.png)
![aa](https://github.com/asirihewage/DOTS/blob/master/SCREENSHOTS/3.png)
![aa](https://github.com/asirihewage/DOTS/blob/master/SCREENSHOTS/5.png)

V2  ==  *Dark mode is available*
We remain committed to making sure all players can enjoy our games. You can turn on Dark Mode to stop eye straining!

##  NOTE
While the game can be played offline, please make sure you are online in order to properly update your DOTS Rank with the world.

##  SUPPORT
Having any problems? Any suggestions? We would love to hear from you! You can reach us at (+94)786141343 via WhatsApp.

PLEASE NOTE: DOTS is completely free to play, but we serve few ads to cover maintenance cost since we do not charge from our users.

   ![build succeeded](https://img.shields.io/badge/build-succeeded-brightgreen.svg)


   ![Test passing](https://img.shields.io/badge/Tests-passing-brightgreen.svg)
